from dataclasses import dataclass, asdict

@dataclass
class LightState:
    on: bool = False
    brightness: int = 0  # 0-255
    color_mode: str = "rgb"
    rgb: tuple[int, int, int] = (255, 255, 255)
    color_temp_mired: int = 250

@dataclass
class LightDevice:
    did: int
    pid: str
    name: str
    retain: bool = True
    state: LightState = LightState()

    # ---------- MQTT topic helpers ----------

    def base_topic(self) -> str:
        return f"vlight/{self.did}"

    def command_topic(self) -> str:
        return f"{self.base_topic()}/set"

    def state_topic(self) -> str:
        return f"{self.base_topic()}/state"

    def ha_discovery_topic(self) -> str:
        return f"homeassistant/light/{self.did}/config"

    def discovery_payload(self) -> dict:
        return {
            "name": self.name,
            "uniq_id": str(self.did),
            "cmd_t": self.command_topic(),
            "stat_t": self.state_topic(),
            "schema": "json",
            "dev": {"mf": "LinknLink", "mdl": self.pid, "ids": [self.did]},
            "sup_clr": True,
            "brt": True,
            "clr_temp": True,
            "rgb": True,
        }

    def state_payload(self) -> dict:
        return {
            "state": "ON" if self.state.on else "OFF",
            "brightness": self.state.brightness,
            "color_mode": self.state.color_mode,
            "rgb_color": list(self.state.rgb),
            "color_temp_mired": self.state.color_temp_mired,
        }