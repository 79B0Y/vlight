from pathlib import Path
import yaml
from dataclasses import dataclass
from typing import Any, Dict, Optional

@dataclass
class BrokerCfg:
    host: str
    port: int = 1883
    username: Optional[str] = None
    password: Optional[str] = None

@dataclass
class LightsCfg:
    count: int = 1
    pid_prefix: str = "LNK-LIGHT"
    base_did: int = 1
    name_prefix: str = "Light"
    retain: bool = True

@dataclass
class AppCfg:
    broker: BrokerCfg
    lights: LightsCfg

def load(path: str | Path) -> AppCfg:
    with open(path, "r", encoding="utf-8") as f:
        raw: Dict[str, Any] = yaml.safe_load(f)
    broker = BrokerCfg(**raw["broker"])
    lights = LightsCfg(**raw["lights"])
    return AppCfg(broker=broker, lights=lights)