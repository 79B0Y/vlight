import json, pathlib
from typing import List
from .device import LightDevice, LightState

class StateStore:
    def __init__(self, path: str | pathlib.Path = "state.json"):
        self.path = pathlib.Path(path)

    def load(self, devices: List[LightDevice]):
        if not self.path.exists():
            return
        data = json.loads(self.path.read_text())
        for dev in devices:
            if str(dev.did) in data:
                dev.state = LightState(**data[str(dev.did)])

    def save(self, devices: List[LightDevice]):
        data = {str(d.did): d.state.__dict__ for d in devices}
        self.path.write_text(json.dumps(data, indent=2))