import json, threading
from typing import List, Dict
import paho.mqtt.client as mqtt
from .device import LightDevice
from .logger import logger
from .config import AppCfg

class MQTTManager:
    def __init__(self, cfg: AppCfg, devices: List[LightDevice]):
        self.cfg = cfg
        self.devices: Dict[str, LightDevice] = {d.command_topic(): d for d in devices}
        self.client = mqtt.Client()
        if cfg.broker.username:
            self.client.username_pw_set(cfg.broker.username, cfg.broker.password)
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message

    def on_connect(self, client, userdata, flags, rc):
        logger.info(f"MQTT connected rc={rc}")
        for topic in self.devices:
            client.subscribe(topic)
        for dev in self.devices.values():
            client.publish(dev.ha_discovery_topic(), json.dumps(dev.discovery_payload()), retain=True)
            client.publish(dev.state_topic(), json.dumps(dev.state_payload()), retain=dev.retain)

    def on_message(self, client, userdata, msg):
        dev = self.devices.get(msg.topic)
        if not dev:
            return
        try:
            payload = json.loads(msg.payload.decode())
        except json.JSONDecodeError:
            logger.warning("Invalid JSON")
            return
        if "state" in payload:
            dev.state.on = payload["state"].upper() == "ON"
        if "brightness" in payload:
            dev.state.brightness = int(payload["brightness"])
        if "rgb_color" in payload:
            dev.state.rgb = tuple(payload["rgb_color"])
        if "color_temp_mired" in payload:
            dev.state.color_temp_mired = int(payload["color_temp_mired"])
        client.publish(dev.state_topic(), json.dumps(dev.state_payload()), retain=dev.retain)

    def start(self):
        self.client.connect(self.cfg.broker.host, self.cfg.broker.port, 60)
        threading.Thread(target=self.client.loop_forever, daemon=True).start()