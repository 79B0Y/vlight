import signal, time
from .config import load
from .device import LightDevice
from .mqtt_manager import MQTTManager
from .state_store import StateStore
from .logger import logger

CFG_PATH = "configuration.yaml"

def build_devices(cfg):
    devices = []
    for i in range(cfg.lights.count):
        did = cfg.lights.base_did + i
        pid = f"{cfg.lights.pid_prefix}-{i:03d}"
        name = f"{cfg.lights.name_prefix} {i+1}"
        devices.append(LightDevice(did=did, pid=pid, name=name, retain=cfg.lights.retain))
    return devices

def main():
    cfg = load(CFG_PATH)
    devices = build_devices(cfg)
    store = StateStore()
    store.load(devices)
    mqttm = MQTTManager(cfg, devices)
    mqttm.start()

    def handle_exit(*_):
        logger.info("Stopping – saving state …")
        store.save(devices)
        exit(0)

    signal.signal(signal.SIGINT, handle_exit)
    signal.signal(signal.SIGTERM, handle_exit)

    logger.info("vlight running – Ctrl+C to quit.")
    while True:
        time.sleep(3600)

if __name__ == "__main__":
    main()