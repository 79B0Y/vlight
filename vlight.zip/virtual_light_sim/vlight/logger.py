import logging
from colorlog import ColoredFormatter

def setup_logger(level: str = "INFO") -> logging.Logger:
    handler = logging.StreamHandler()
    handler.setFormatter(
        ColoredFormatter(
            "%(log_color)s[%(asctime)s] %(levelname)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
    )
    logger = logging.getLogger("vlight")
    logger.setLevel(level)
    logger.addHandler(handler)
    logger.propagate = False
    return logger

logger = setup_logger()