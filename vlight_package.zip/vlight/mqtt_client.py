
import paho.mqtt.client as mqtt

class MQTTManager:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.client = mqtt.Client()

    def on_connect(self, client, userdata, flags, rc):
        self.logger.info("Connected to MQTT Broker with result code " + str(rc))

    def start(self):
        mqtt_cfg = self.config['mqtt']
        self.client.username_pw_set(mqtt_cfg['username'], mqtt_cfg['password'])
        self.client.on_connect = self.on_connect
        self.client.connect(mqtt_cfg['host'], mqtt_cfg['port'], 60)
        self.client.loop_start()
