
import logging

def init_logger(config):
    log_path = config['logging']['file']
    log_level = getattr(logging, config['logging']['level'].upper(), logging.INFO)
    logging.basicConfig(
        filename=log_path,
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(message)s"
    )
    return logging.getLogger("vlight")
