
from setuptools import setup, find_packages

setup(
    name="vlight",
    version="0.4.2",
    description="Virtual MQTT Light with iSG HA discovery format",
    author="LinknLink",
    packages=find_packages(),
    install_requires=[
        "paho-mqtt",
        "pyyaml"
    ],
    entry_points={
        "console_scripts": [
            "vlight = vlight.main:main"
        ]
    },
    include_package_data=True,
)
