
import paho.mqtt.client as mqtt
from vlight.light_device import LightDevice

class MQTTManager:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.client = mqtt.Client()
        self.client.username_pw_set(config['mqtt']['username'], config['mqtt']['password'])
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.devices = []

    def on_connect(self, client, userdata, flags, rc):
        self.logger.info("Connected to MQTT broker with code " + str(rc))
        for device in self.devices:
            self.client.subscribe(device.command_topic)
            device.announce_discovery()
            device.publish_state()

    def on_message(self, client, userdata, msg):
        for device in self.devices:
            if msg.topic == device.command_topic:
                device.handle_command(msg.payload.decode())

    def start(self):
        mqtt_cfg = self.config['mqtt']
        base_topic = mqtt_cfg['base_topic']
        discovery_prefix = mqtt_cfg.get('discovery_prefix', 'homeassistant')
        simulate_behavior = self.config['lights'].get('simulate_behavior', False)

        for definition in self.config['lights']['definitions']:
            state = dict(self.config['lights']['default_state'])
            device = LightDevice(
                did=definition['did'],
                pid=definition['pid'],
                mqtt_client=self.client,
                discovery_prefix=discovery_prefix,
                base_topic=base_topic,
                logger=self.logger,
                initial_state=state,
                simulate=simulate_behavior
            )
            self.devices.append(device)

        self.client.connect(mqtt_cfg['host'], mqtt_cfg['port'], 60)
        self.client.loop_start()
