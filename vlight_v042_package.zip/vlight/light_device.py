# light device class placeholder with iSG format support
