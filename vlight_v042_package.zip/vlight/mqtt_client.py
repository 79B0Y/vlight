# mqtt manager placeholder for v0.4.2
